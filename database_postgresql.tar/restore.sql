--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Diet_app";
--
-- Name: Diet_app; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Diet_app" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Polish_Poland.1250';


ALTER DATABASE "Diet_app" OWNER TO postgres;

\connect "Diet_app"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "Diet_app"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "Diet_app" IS 'It''s a data base for my diet app.';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity (
    id_activity integer NOT NULL,
    activity character varying(50) NOT NULL,
    details character varying(200) NOT NULL
);


ALTER TABLE public.activity OWNER TO postgres;

--
-- Name: activity_id_activity_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_id_activity_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_id_activity_seq OWNER TO postgres;

--
-- Name: activity_id_activity_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_id_activity_seq OWNED BY public.activity.id_activity;


--
-- Name: daily_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_plans (
    id_daily_plan bigint NOT NULL,
    id_meal1 integer,
    id_meal2 integer,
    id_meal3 integer,
    id_meal4 integer,
    id_meal5 integer,
    id_meal6 integer,
    id_diet smallint,
    daily_calories real,
    daily_carbohydrates real,
    daily_protein real,
    daily_fats real
);


ALTER TABLE public.daily_plans OWNER TO postgres;

--
-- Name: daily_plans_id_daily_plan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.daily_plans_id_daily_plan_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_plans_id_daily_plan_seq OWNER TO postgres;

--
-- Name: daily_plans_id_daily_plan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.daily_plans_id_daily_plan_seq OWNED BY public.daily_plans.id_daily_plan;


--
-- Name: diet_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diet_plans (
    id_diet_plan integer NOT NULL,
    id_user integer,
    id_day1 integer,
    id_day2 integer,
    id_day3 integer,
    id_day4 integer,
    id_day5 integer,
    id_day6 integer,
    id_day7 integer
);


ALTER TABLE public.diet_plans OWNER TO postgres;

--
-- Name: diet_plans_id_diet_plan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diet_plans_id_diet_plan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diet_plans_id_diet_plan_seq OWNER TO postgres;

--
-- Name: diet_plans_id_diet_plan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diet_plans_id_diet_plan_seq OWNED BY public.diet_plans.id_diet_plan;


--
-- Name: diets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diets (
    id_diet integer NOT NULL,
    diet character varying(50) NOT NULL,
    details character varying(250)
);


ALTER TABLE public.diets OWNER TO postgres;

--
-- Name: diets_id_diet_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diets_id_diet_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diets_id_diet_seq OWNER TO postgres;

--
-- Name: diets_id_diet_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diets_id_diet_seq OWNED BY public.diets.id_diet;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goals (
    id_goal integer NOT NULL,
    goal character varying(50) NOT NULL
);


ALTER TABLE public.goals OWNER TO postgres;

--
-- Name: goals_id_goal_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.goals_id_goal_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.goals_id_goal_seq OWNER TO postgres;

--
-- Name: goals_id_goal_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.goals_id_goal_seq OWNED BY public.goals.id_goal;


--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredients (
    id_ingredients integer NOT NULL,
    "1" character varying(250),
    "2" character varying(250),
    "3" character varying(250),
    "4" character varying(250),
    "5" character varying(250),
    "6" character varying(250),
    "7" character varying(250),
    "8" character varying(250),
    "9" character varying(250),
    "10" character varying(250),
    "11" character varying(250),
    "12" character varying(250),
    "13" character varying(250),
    "14" character varying(250),
    "15" character varying(250),
    "16" character varying(250),
    "17" character varying(250),
    "18" character varying(250),
    "19" character varying(250),
    "20" character varying(250),
    "21" character varying(250),
    "22" character varying(250),
    "23" character varying(250),
    "24" character varying(250)
);


ALTER TABLE public.ingredients OWNER TO postgres;

--
-- Name: ingredients_id_ingredients_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingredients_id_ingredients_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingredients_id_ingredients_seq OWNER TO postgres;

--
-- Name: ingredients_id_ingredients_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingredients_id_ingredients_seq OWNED BY public.ingredients.id_ingredients;


--
-- Name: meals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meals (
    id_meal integer NOT NULL,
    id_ingredients integer,
    meal character varying(200),
    link character varying(200) NOT NULL,
    calories real,
    carbohydrates_g real,
    protein_g real,
    fat_g real,
    sugars_g real,
    fat_calories real,
    calcium_mg real,
    cholesterol_mg real,
    dietary_fiber_g real,
    folate_mcg real,
    iron_mg real,
    magnesium_mg real,
    niacin_equivalents_mg real,
    potassium_mg real,
    saturated_fat_g real,
    sodium_mg real,
    thiamin_mg real,
    vitamin_a_iu real,
    vitamin_b6_mg real,
    vitamin_c_mg real
);


ALTER TABLE public.meals OWNER TO postgres;

--
-- Name: meals_id_meal_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.meals_id_meal_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.meals_id_meal_seq OWNER TO postgres;

--
-- Name: meals_id_meal_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.meals_id_meal_seq OWNED BY public.meals.id_meal;


--
-- Name: sexes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sexes (
    id_sex smallint NOT NULL,
    sex character varying(10)
);


ALTER TABLE public.sexes OWNER TO postgres;

--
-- Name: sexes_id_sex_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sexes_id_sex_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sexes_id_sex_seq OWNER TO postgres;

--
-- Name: sexes_id_sex_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sexes_id_sex_seq OWNED BY public.sexes.id_sex;


--
-- Name: units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units (
    id_units_of_measure integer NOT NULL,
    units character varying(50) NOT NULL
);


ALTER TABLE public.units OWNER TO postgres;

--
-- Name: units_id_units_of_measure_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_id_units_of_measure_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_id_units_of_measure_seq OWNER TO postgres;

--
-- Name: units_id_units_of_measure_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_id_units_of_measure_seq OWNED BY public.units.id_units_of_measure;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id_user integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    age smallint NOT NULL,
    height_in_cm real NOT NULL,
    weight_in_kg real NOT NULL,
    e_mail character varying(250) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    last_login timestamp without time zone,
    id_units_of_measure smallint NOT NULL,
    id_sex smallint NOT NULL,
    id_goal smallint NOT NULL,
    id_diet smallint NOT NULL,
    id_activity smallint NOT NULL,
    caloric_demand real,
    carbohydrates_daily real,
    proteins_daily real,
    fats_daily real
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_user_seq OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_user_seq OWNED BY public.users.id_user;


--
-- Name: activity id_activity; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity ALTER COLUMN id_activity SET DEFAULT nextval('public.activity_id_activity_seq'::regclass);


--
-- Name: daily_plans id_daily_plan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans ALTER COLUMN id_daily_plan SET DEFAULT nextval('public.daily_plans_id_daily_plan_seq'::regclass);


--
-- Name: diet_plans id_diet_plan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans ALTER COLUMN id_diet_plan SET DEFAULT nextval('public.diet_plans_id_diet_plan_seq'::regclass);


--
-- Name: diets id_diet; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diets ALTER COLUMN id_diet SET DEFAULT nextval('public.diets_id_diet_seq'::regclass);


--
-- Name: goals id_goal; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals ALTER COLUMN id_goal SET DEFAULT nextval('public.goals_id_goal_seq'::regclass);


--
-- Name: ingredients id_ingredients; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredients ALTER COLUMN id_ingredients SET DEFAULT nextval('public.ingredients_id_ingredients_seq'::regclass);


--
-- Name: meals id_meal; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meals ALTER COLUMN id_meal SET DEFAULT nextval('public.meals_id_meal_seq'::regclass);


--
-- Name: sexes id_sex; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sexes ALTER COLUMN id_sex SET DEFAULT nextval('public.sexes_id_sex_seq'::regclass);


--
-- Name: units id_units_of_measure; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units ALTER COLUMN id_units_of_measure SET DEFAULT nextval('public.units_id_units_of_measure_seq'::regclass);


--
-- Name: users id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id_user SET DEFAULT nextval('public.users_id_user_seq'::regclass);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity (id_activity, activity, details) FROM stdin;
\.
COPY public.activity (id_activity, activity, details) FROM '$$PATH$$/3100.dat';

--
-- Data for Name: daily_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_plans (id_daily_plan, id_meal1, id_meal2, id_meal3, id_meal4, id_meal5, id_meal6, id_diet, daily_calories, daily_carbohydrates, daily_protein, daily_fats) FROM stdin;
\.
COPY public.daily_plans (id_daily_plan, id_meal1, id_meal2, id_meal3, id_meal4, id_meal5, id_meal6, id_diet, daily_calories, daily_carbohydrates, daily_protein, daily_fats) FROM '$$PATH$$/3110.dat';

--
-- Data for Name: diet_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diet_plans (id_diet_plan, id_user, id_day1, id_day2, id_day3, id_day4, id_day5, id_day6, id_day7) FROM stdin;
\.
COPY public.diet_plans (id_diet_plan, id_user, id_day1, id_day2, id_day3, id_day4, id_day5, id_day6, id_day7) FROM '$$PATH$$/3114.dat';

--
-- Data for Name: diets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diets (id_diet, diet, details) FROM stdin;
\.
COPY public.diets (id_diet, diet, details) FROM '$$PATH$$/3104.dat';

--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goals (id_goal, goal) FROM stdin;
\.
COPY public.goals (id_goal, goal) FROM '$$PATH$$/3098.dat';

--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredients (id_ingredients, "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24") FROM stdin;
\.
COPY public.ingredients (id_ingredients, "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24") FROM '$$PATH$$/3106.dat';

--
-- Data for Name: meals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meals (id_meal, id_ingredients, meal, link, calories, carbohydrates_g, protein_g, fat_g, sugars_g, fat_calories, calcium_mg, cholesterol_mg, dietary_fiber_g, folate_mcg, iron_mg, magnesium_mg, niacin_equivalents_mg, potassium_mg, saturated_fat_g, sodium_mg, thiamin_mg, vitamin_a_iu, vitamin_b6_mg, vitamin_c_mg) FROM stdin;
\.
COPY public.meals (id_meal, id_ingredients, meal, link, calories, carbohydrates_g, protein_g, fat_g, sugars_g, fat_calories, calcium_mg, cholesterol_mg, dietary_fiber_g, folate_mcg, iron_mg, magnesium_mg, niacin_equivalents_mg, potassium_mg, saturated_fat_g, sodium_mg, thiamin_mg, vitamin_a_iu, vitamin_b6_mg, vitamin_c_mg) FROM '$$PATH$$/3108.dat';

--
-- Data for Name: sexes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sexes (id_sex, sex) FROM stdin;
\.
COPY public.sexes (id_sex, sex) FROM '$$PATH$$/3096.dat';

--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units (id_units_of_measure, units) FROM stdin;
\.
COPY public.units (id_units_of_measure, units) FROM '$$PATH$$/3102.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id_user, username, password, first_name, last_name, age, height_in_cm, weight_in_kg, e_mail, created_on, last_login, id_units_of_measure, id_sex, id_goal, id_diet, id_activity, caloric_demand, carbohydrates_daily, proteins_daily, fats_daily) FROM stdin;
\.
COPY public.users (id_user, username, password, first_name, last_name, age, height_in_cm, weight_in_kg, e_mail, created_on, last_login, id_units_of_measure, id_sex, id_goal, id_diet, id_activity, caloric_demand, carbohydrates_daily, proteins_daily, fats_daily) FROM '$$PATH$$/3112.dat';

--
-- Name: activity_id_activity_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_id_activity_seq', 4, true);


--
-- Name: daily_plans_id_daily_plan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.daily_plans_id_daily_plan_seq', 1, false);


--
-- Name: diet_plans_id_diet_plan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diet_plans_id_diet_plan_seq', 1, false);


--
-- Name: diets_id_diet_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diets_id_diet_seq', 10, true);


--
-- Name: goals_id_goal_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.goals_id_goal_seq', 7, true);


--
-- Name: ingredients_id_ingredients_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingredients_id_ingredients_seq', 1, false);


--
-- Name: meals_id_meal_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meals_id_meal_seq', 1, false);


--
-- Name: sexes_id_sex_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sexes_id_sex_seq', 2, true);


--
-- Name: units_id_units_of_measure_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_id_units_of_measure_seq', 2, true);


--
-- Name: users_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_user_seq', 3, true);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id_activity);


--
-- Name: daily_plans daily_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_pkey PRIMARY KEY (id_daily_plan);


--
-- Name: diet_plans diet_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_pkey PRIMARY KEY (id_diet_plan);


--
-- Name: diets diets_diet_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diets
    ADD CONSTRAINT diets_diet_key UNIQUE (diet);


--
-- Name: diets diets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diets
    ADD CONSTRAINT diets_pkey PRIMARY KEY (id_diet);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id_goal);


--
-- Name: ingredients ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (id_ingredients);


--
-- Name: meals meals_link_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_link_key UNIQUE (link);


--
-- Name: meals meals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_pkey PRIMARY KEY (id_meal);


--
-- Name: sexes sexes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sexes
    ADD CONSTRAINT sexes_pkey PRIMARY KEY (id_sex);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id_units_of_measure);


--
-- Name: users users_e_mail_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_e_mail_key UNIQUE (e_mail);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_user);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: daily_plans daily_plans_id_diet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_diet_fkey FOREIGN KEY (id_diet) REFERENCES public.diets(id_diet);


--
-- Name: daily_plans daily_plans_id_meal1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_meal1_fkey FOREIGN KEY (id_meal1) REFERENCES public.meals(id_meal);


--
-- Name: daily_plans daily_plans_id_meal2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_meal2_fkey FOREIGN KEY (id_meal2) REFERENCES public.meals(id_meal);


--
-- Name: daily_plans daily_plans_id_meal3_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_meal3_fkey FOREIGN KEY (id_meal3) REFERENCES public.meals(id_meal);


--
-- Name: daily_plans daily_plans_id_meal4_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_meal4_fkey FOREIGN KEY (id_meal4) REFERENCES public.meals(id_meal);


--
-- Name: daily_plans daily_plans_id_meal5_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_meal5_fkey FOREIGN KEY (id_meal5) REFERENCES public.meals(id_meal);


--
-- Name: daily_plans daily_plans_id_meal6_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_id_meal6_fkey FOREIGN KEY (id_meal6) REFERENCES public.meals(id_meal);


--
-- Name: diet_plans diet_plans_id_day1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day1_fkey FOREIGN KEY (id_day1) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_day2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day2_fkey FOREIGN KEY (id_day2) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_day3_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day3_fkey FOREIGN KEY (id_day3) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_day4_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day4_fkey FOREIGN KEY (id_day4) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_day5_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day5_fkey FOREIGN KEY (id_day5) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_day6_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day6_fkey FOREIGN KEY (id_day6) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_day7_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_day7_fkey FOREIGN KEY (id_day7) REFERENCES public.daily_plans(id_daily_plan);


--
-- Name: diet_plans diet_plans_id_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_id_user_fkey FOREIGN KEY (id_user) REFERENCES public.users(id_user);


--
-- Name: meals meals_id_ingredients_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_id_ingredients_fkey FOREIGN KEY (id_ingredients) REFERENCES public.ingredients(id_ingredients);


--
-- Name: users users_id_activity_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_activity_fkey FOREIGN KEY (id_activity) REFERENCES public.activity(id_activity);


--
-- Name: users users_id_diet_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_diet_fkey FOREIGN KEY (id_diet) REFERENCES public.diets(id_diet);


--
-- Name: users users_id_goal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_goal_fkey FOREIGN KEY (id_goal) REFERENCES public.goals(id_goal);


--
-- Name: users users_id_sex_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_sex_fkey FOREIGN KEY (id_sex) REFERENCES public.sexes(id_sex);


--
-- Name: users users_id_units_of_measure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_units_of_measure_fkey FOREIGN KEY (id_units_of_measure) REFERENCES public.units(id_units_of_measure);


--
-- PostgreSQL database dump complete
--

